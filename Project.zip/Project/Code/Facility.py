class Facility:

    def __init__(self, facility_name=0) :
        self.facility_Name = facility_name

    def addFacility(self) :
        self.file1 = open("C:/CPRG216K/Project/Project Data/files/facilities.txt", "a")
        self.facility = input("Enter Facility name:\n")
        self.file1.write(self.facility)
        return self.file1

    def displayFacilities(self) :
        self.file2 = open("C:/CPRG216K/Project/Project Data/files/facilities.txt", "r")
        self.file3 = self.file2.read()
        self.file4 = self.file3.splitlines()
        for self.i in range(len(self.file4)) :
            self.file5 = self.file4[self.i]
            print(f"{self.file5}\n\n")

    def writeListOffacilitiesToFile(self) :
        self.file6 = open("C:/CPRG216K/Project/Project Data/files/facilities.txt", "w")
        self.file7 = self.file6.write(self.file1)
        return self.file7

f = Facility()
while True :
    option = int(input("Facilities Menu:\n1 - Display Facilities list\n2 - Add Facility\n3 - Back to the Main Menu\n"))
    if option == 1 :
        f.displayFacilities()
    elif option == 2 :
        f.addFacility()
    elif option == 3 :
        break
    else :
        print("Please enter correct option")