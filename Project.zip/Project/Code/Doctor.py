class Doctor :

    def __init__(self, ID=0, name=0, specialization=0, working_Time=0, qualification=0, room_Number=0) :
        self.ID = ID
        self.name = name
        self.specialization = specialization
        self.working_Time = working_Time
        self.qualification = qualification
        self.room_number = room_Number

    def readDoctorsFile(self) :
        self.file1 = open("C:/CPRG216K/Project/Project Data/files/doctors.txt", "r")
        self.file2 = self.file.read()
        self.file3 = self.file2.splitlines()
        return self.file3
        
        
    def formatDoctorInfo(self) :
        self.file3 = self.file2.splitlines()
        return self.file3

    def displayDoctorInfo(self) :
        print(self.file3)

    def searchDoctorByID(self) :
        ID = input("Enter the Doctor ID:\n")
        flag = False
        for self.i in range(len(self.file3)) :
            self.file4 = self.file3[self.i].split("_")
            self.ID = self.file4[0]
            self.name = self.file4[1]
            self.specialization = self.file4[2]
            self.working_Time = self.file4[3]
            self.qualification = self.file4[4]
            self.room_number = self.file4[5]
            if ID == self.ID :
                print(f"ID\tName\tSpeciality\tTiming\tQualification\tRoom Number\n\n{self.ID}\t{self.name}\t{self.specialization}\t{self.working_Time}\t{self.qualification}\t{self.room_number}")
                flag = True
        if flag == False:
            print("Can't find the doctor with the same ID on the system")

    def searchDoctorByName(self) :
        name = input("Enter the Doctor Name:\n")
        flag = False
        for self.i in range(len(self.file3)) :
            self.file4 = self.file3[self.i].split("_")
            self.ID = self.file4[0]
            self.name = self.file4[1]
            self.specialization = self.file4[2]
            self.working_Time = self.file4[3]
            self.qualification = self.file4[4]
            self.room_number = self.file4[5]
            if name == self.name :
                print(f"ID\tName\tSpeciality\tTiming\tQualification\tRoom Number\n\n{self.ID}\t{self.name}\t{self.specialization}\t{self.working_Time}\t{self.qualification}\t{self.room_number}")
                flag = True
        if flag == False:
            print("Can't find the doctor with the same ID on the system")

    def enterDoctorInfo(self) :
        self.ID = input("Enter the doctor’s ID:\n")
        self.name = input("Enter the doctor’s name:\n")
        self.specialization = input("Enter the doctor’s specility:\n")
        self.working_Time = input("Enter the doctor’s timing (e.g., 7am-10pm):\n")
        self.qualification = input("Enter the doctor’s qualification:\n")
        self.room_number = input("Enter the doctor’s room number:\n")
        self.file5 = [self.ID,self.name,self.specialization,self.working_Time,self.qualification,self.room_number]
        self.file6 = open("C:/CPRG216K/Project/Project Data/files/doctors.txt", "a")
        self.file6.write(self.file5)
        return self.file6

    def editDoctorInfo(self) :
        ID = input("Please enter the id of the doctor that you want to edit their information:\n")
        for self.i in range(len(self.file3)) :
            self.file4 = self.file3[self.i].split("_")
            self.ID = self.file4[0]
            self.name = self.file4[1]
            self.specialization = self.file4[2]
            self.working_Time = self.file4[3]
            self.qualification = self.file4[4]
            self.room_number = self.file4[5]
            if ID == self.ID :
                self.ID = ID
                self.name = input("Enter new Name:\n")
                self.specialization = input("Enter new Specilist in:\n")
                self.working_Time = input("Enter new Timing:\n")
                self.qualification = input("Enter new Qualification:\n")
                self.room_number = input("Enter new Room number:\n")
                self.file3[self.i] = [self.ID,self.name,self.specialization,self.working_Time,self.qualification,self.room_number]
        return self.file3

    def writeListOfDoctorsToFile(self) :
        self.file7 = open("C:/CPRG216K/Project/Project Data/files/doctors.txt", "w")
        self.file7.write()

        
            
            

#d = Doctor()
#d.readDoctorsFile()
#d.formatDoctorInfo()
#d.searchDoctorByID()
#d.searchDoctorByName()